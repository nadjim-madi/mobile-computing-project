

def fonction4():

    pass
