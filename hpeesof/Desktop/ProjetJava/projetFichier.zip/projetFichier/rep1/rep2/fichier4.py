

def fonction5():
    pass