#! C:\Users\Samy\Desktop\rep1 python3
#-*- utf-8 -*-
def fonction1(larg:int, long:int,jsp:int)-> int:
	"""	!
	@brief fonction1
	fonction1
	@version 0.1
	@author ML
	@param larg
	@param  long
	@param jsp
	return fonction1
	"""

    # Corps de la fonction 1
    return 1



def fonction2()->int:
	"""	!
	@brief fonction2
	fonction2
	@version 0.1
	@author ML
	"""

    # Corps de la fonction 2
    pass

def fonction3()->int:
	"""	!
	@brief fonction3
	fonction3
	@version 0.1
	@author ML
	"""

    # Corps de la fonction 3
    pass

