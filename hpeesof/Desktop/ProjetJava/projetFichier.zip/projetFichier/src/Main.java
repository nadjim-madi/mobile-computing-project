
public class Main {

	public static void main(String[] args) {
		
		
		GUI fenetre = new GUI();
	}

}
