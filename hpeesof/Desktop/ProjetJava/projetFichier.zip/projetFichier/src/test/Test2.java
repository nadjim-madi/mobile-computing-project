package test;

import java.io.File;

import classes.FichierPython;
import classes.Fonction;
import classes.Repertoire;

public class Test2 {
	
	public static void main(String[] args) {
		
		try {
		Repertoire rep = new Repertoire("C:\\Users\\Samy\\Desktop\\rep1");
		
		rep.listerFichierPy();
		//rep.afficheFile();
		for(FichierPython fichier : rep.getFichierPy()) {
			fichier.listerFonctions();
		}
		//rep.afficheFile();
		//System.out.println("Le nombre de fichier python dans ce repertoire est : " + rep.getFichierPy().size());
		//System.out.println("Nombre de fonction python dans ce repertoire est :" + rep.nombreFonction());
		FichierPython p = new FichierPython("C:\\\\Users\\\\Samy\\\\Desktop\\\\rep1\\fichier1.py");
		//System.out.println("premiere ligne :" + p.ContientPremiereLignes());
		//System.out.println("deuxieme ligne :" + p.ContientDeuxiemeLignes());
		p.ajoutDeuxLigne();
		//rep.afficheStat();
		
		Fonction f;
		f = new Fonction("def surfaceRectangle(para1: int, para2:int) -> int:"
		    + "\"\"\""
		    +"brief surface d'un rectangle."
		    +"calcule la surface d'un rectangle"
		    +"@version 0.1"
		    +"@author ML"
		    +"@param longueur la longueur du rectangle"
		    +"@param largeur la largeur du rectangle"
		    +"@return la surface du rectangle"
		    + "\"\"\""
		    +"return longueur * largeur"

				);
		
		f.ajoutPyDoc();
		System.out.println(f.toString());
		//System.out.println(f.hasTypeAnnotations());
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}

}
