package classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import exception.NotPythonFileException;
import exception.PremiereLignesExisteException;

public class FichierPython extends File {
	
	private ArrayList<Fonction> fonctions;
	
	
	
	
	
	public FichierPython(String chemin) throws NotPythonFileException {
		
		super(chemin);
		if(!this.isFile() || !this.getName().toLowerCase().endsWith(".py") ) {
			throw new NotPythonFileException();
		}
		fonctions = new ArrayList<Fonction>();
	}
	
	
	
	
//Lister les fonctions dans la ArrayList fonctions
	public void listerFonctions() throws IOException  {
		fonctions.clear();
		BufferedReader lecteur = new BufferedReader(new FileReader(this.getAbsolutePath()));
        String ligne;
        String s = "";
        
        while((ligne = lecteur.readLine()) != null && !ligne.startsWith("def")) {
        	ligne = lecteur.readLine();
        	
        	
        	
        }
        s+= ligne + "\n";
        boolean sortir = false;
        while((ligne = lecteur.readLine()) != null && !sortir ) {
        	if(ligne.startsWith("def")) {
        		fonctions.add(new Fonction(s));
        		s = "";
       		
        	}
        	s+= ligne + "\n";
        	
        }
        fonctions.add(new Fonction(s));
        
        
	}
	
	
	
	
	
//vrai si contient la premiere ligne de shebang
	public boolean contientPremiereLignes() throws IOException {
		BufferedReader lecteur = new BufferedReader(new FileReader(this.getAbsolutePath()));
		String ligne;
		ligne = lecteur.readLine();
		if(ligne.startsWith("#!") && ligne.endsWith("python3")){
				return true;
					}
		return false;
		
		
		
	}
	
	
//vrai si contient la ligne de utf8	
	public boolean contientDeuxiemeLignes() throws IOException {
		BufferedReader lecteur = new BufferedReader(new FileReader(this.getAbsolutePath()));
		String ligne;
		ligne = lecteur.readLine();
		
		ligne = lecteur.readLine();
				if(ligne.startsWith("#-*-") && ligne.endsWith("-*-")) {
					return true;
				}
					
		return false;
		
		
		
	}
	
//vrai si contient les 2 lignes
	public boolean contientLesDeuxLignes() throws IOException{
		return (contientDeuxiemeLignes() && contientPremiereLignes());
		
	}
	

	
//pour l'ajout des deux premieres lignes
	public void ajoutDeuxLigne() throws IOException, PremiereLignesExisteException {
		if(!contientLesDeuxLignes()) {
			BufferedReader lecteur = new BufferedReader(new FileReader(this.getAbsolutePath()));
	        String ligne;
	        String string="" ;
	        String premiereLigne = "#! " + this.getParent() + " python3" + "\n";
	        String deuxiemeLigne = "#-*- utf-8 -*-" + "\n";
	        
	        
	        
	        
	        ligne = lecteur.readLine();
	        ligne = lecteur.readLine();
	        
	        //lecture du fichier:
	        while ((ligne = lecteur.readLine()) != null) {
	        	string = string + ligne + "\n";
	        	
	        	
	        }
	        lecteur.close();
	        
	        
	        //ecriture dans le fichier:
	        BufferedWriter ecrit = new BufferedWriter(new FileWriter(this.getAbsolutePath()));
	        ecrit.write(premiereLigne);
	        ecrit.write(deuxiemeLigne);
	        ecrit.write(string);
	        ecrit.close();
	        
	        
			
			
		}
		else {
			throw new PremiereLignesExisteException();
		}
		
		
	}
	
	
	
	public boolean contientPydoc() {
		for(Fonction f : fonctions) {
			if(!f.existePyDoc()) {
				
				return false;
			}
		}
		return true;
	}
	
	public boolean contientTypage() {
		for(Fonction f: fonctions) {
			if(!f.existeAnnotationType())
				return false;
		}
		return true;
		
		
	}
	
//pour l'ajour du PyDoc
	public void ajoutPyDoc() throws IOException {
		if(!contientPydoc()) {
		for(Fonction f: fonctions) {
			f.ajoutPyDoc();
		}
		
		String first = "";
		String last = "";
		BufferedReader lecteur = new BufferedReader(new FileReader(this.getAbsoluteFile()));
		String ligne;
		while((ligne = lecteur.readLine())!=null && !ligne.startsWith("def")) {
			first += ligne + "\n";
			
			
		}
		
		
		while((ligne = lecteur.readLine()) != null) {
			if(ligne == "if __name__ == \"__main__\":")
				last+= ligne + "\n";
			
		}
		
		lecteur.close();
        BufferedWriter ecrit = new BufferedWriter(new FileWriter(this.getAbsolutePath()));
        

        ecrit.write(first);
        for(Fonction f : fonctions) {
        	ecrit.write(f.toString());
        }
        ecrit.write(last);
        ecrit.close();
		
		
		
		
		}
	}
	
	
	
	
	
	public ArrayList<Fonction> getFonctions() {
		return fonctions;
			}

	
		
	
	//Retourne le nombre de fonctions dans ce fichier python
	public int nombreFonction() throws IOException {
		listerFonctions();
		return fonctions.size();
		}

			
	
	
	
	
	
	
}