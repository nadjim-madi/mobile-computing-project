package classes;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Fonction {
private String contenu;


public Fonction(String contenu) {
	this.contenu = contenu;
}


//detection de si le pydocExiste :
public boolean existePyDoc() {
 
    int premierGui = contenu.indexOf("\"\"\"");
    int dernierGui = contenu.lastIndexOf("\"\"\"");
    
    if (premierGui != -1 && dernierGui != -1 && premierGui < dernierGui) {
        String docString = contenu.substring(premierGui, dernierGui + 3);

        if(!docString.contains("@brief") || !docString.contains("@version") || !docString.contains("@author") ){
        	return false;
        }
        if(docString.contains("return")) {
        	if(!docString.contains("@return")) {
        		return false;
        	}
        }
        int index = docString.indexOf("@param");
        int compteur = 0;
        

        while (index != -1) {
            compteur++;
            index = docString.indexOf("@param", index + 1);
        }
        
        if(compteur !=nombreDeParametres()) {
        	return false;
        }
        return docString.trim().length() > 3; 
    }
    
    return false; 
}



//Retourne vrai si il existe les annotation de type
public boolean existeAnnotationType () {
    Pattern pattern = Pattern.compile("\\w+\\(.*?\\)\\s*->\\s*\\w+");
    Matcher matcher = pattern.matcher(contenu);

    if (matcher.find()) {
        String signature = matcher.group(); 
        String[] parts = signature.split("\\(");
        //recupere les parametre dans un tableau
        if(parts.length>1) {
        	 String paramsPart = parts[1].split("\\)")[0]; 
             String[] parameters = paramsPart.split(","); 
             if(parameters[0] == "") {
            	 return true;
             }
       //verifier si il y a : apres les parametres
        for(String para: parameters) {
        	
        	if(!para.contains(":")) {
        		return false;
        	}
        }
        }
        
        return true;
        
    }

    return false;
}


//L'ajout du PyDoc
public void ajoutPyDoc() {
	if(!existePyDoc()) {
		String resultat;
		resultat = "\t"+"\"\"\""
				+"\t"+"!" + "\n"
			    +"\t"+"@brief " + nomFonction()+"\n"
			    +"\t"+nomFonction() + "\n"
			    +"\t"+"@version 0.1" + "\n"
			    +"\t"+"@author ML" + "\n";
		
		
		
			 String nomPara;
			 Pattern pattern = Pattern.compile("\\w+\\(.*?\\)\\s*->\\s*\\w+");
			 Matcher matcher = pattern.matcher(contenu);
			 
			 //ajout du pyDoc des parametres
			 if(matcher.find()) {

				 String signature = matcher.group();
				 if(nombreDeParametres()!=0) {
				 		int index1= signature.indexOf("(");
				 		int index2 = signature.indexOf(")");
				 		String parametres = signature.substring(index1+1,index2);
				 		String[] params = parametres.split(",");
				 		for(String p : params) {
				 			String nomP = p.substring(0,p.indexOf(":"));
				 			resultat += "\t" +"@param " + nomP +"\n";
				 		}
				 }
				 
				 	
			
				 
				 if(contenu.contains("return")) {
					 resultat += "\t" + "@return " + nomFonction() + "\n";
				 }
				 
				 signature = "def " + signature;
				 signature += ":";
				 resultat += "\t" +"\"\"\"" + "\n";
				 resultat =signature +"\n" + resultat;
				 
				 
				 

				 if(this.contenu.contains("\"\"\"")) {
				 resultat += this.contenu.substring(this.contenu.lastIndexOf("\"\"\"")+3);
				 }
				 else {
					 String s = contenu.substring(signature.lastIndexOf(":")+1);
					 resultat+= s;
				 }
				 this.contenu = resultat;
		
		
		
		
		
		
		
		
		
		
		}
		}
	
	
	
	
	
}




//Retourne le nombre de parametres
public int nombreDeParametres(){
	 Pattern pattern = Pattern.compile("\\w+\\(.*?\\)\\s*->\\s*\\w+");
	 Matcher matcher = pattern.matcher(contenu);
	 int compteur = 1;
	 if(matcher.find()) {

	 String signature = matcher.group();
	 if(signature.indexOf(")") - signature.indexOf("(") == 1 ) {
		 return 0;
	 }
	 
	 
	 
    int index = signature.indexOf(",");
    
    while (index != -1) {
        compteur++;
        index = signature.indexOf(",", index + 1);
    }
    
    
    
    return compteur;
}
	 
	 return 0;
	
}


//Retourne le nom de la fonction
public String nomFonction() {
	 Pattern pattern = Pattern.compile("\\w+\\(.*?\\)\\s*->\\s*\\w+");
	 Matcher matcher = pattern.matcher(contenu);
	 if(matcher.find()) {
	 String signature = matcher.group();
	 int index = signature.indexOf("(");
	 String nomF = signature.substring(0,index);
	 return nomF;
		 
		 
		 
	 }
	 
	
	
	 
	 return null;
}


@Override
public String toString() {
	 return contenu;
}





}
