package classes;

import java.io.IOException;

public class Statistique {
		
	Repertoire rep;
	
	
	
	
	public Statistique(Repertoire p) {
		rep = p;
	}
	
	
	
	public double pourcentageFichierAvecDeuxLigne() throws IOException {
		double i = 0;
		for(FichierPython fichier : rep.getFichierPy()) {
			if(fichier.contientLesDeuxLignes()) {
				i++;
			}
		}
		
		return (i / rep.getFichierPy().size() ) *100;
	}
	
	public double pourcentageFonctionAvecPydoc() throws IOException {
		double i = 0;
		for(FichierPython fichier : rep.getFichierPy()) {
			for(Fonction fonction: fichier.getFonctions()) {
				if(fonction.existePyDoc()) {
					i++;
				}
				
			}
		}
		return (i / rep.nombreFonction() ) *100;
	}
	
	public double pourcentageFonctionAvecAnnotation() throws IOException {
		double i = 0;
		for(FichierPython fichier : rep.getFichierPy()) {
			for(Fonction fonction: fichier.getFonctions()) {
				if(fonction.existeAnnotationType()) {
					i++;
				}
				
		}
		}
		return (i / rep.nombreFonction() ) *100;
	}
	
	
	
	
	
	
	
	
}
