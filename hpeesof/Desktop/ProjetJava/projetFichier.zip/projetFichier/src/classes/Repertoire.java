package classes;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import exception.NotDirectoryException;
import exception.NotPythonFileException;

public class Repertoire extends File {

	File[] fichiers;
	ArrayList <FichierPython> fichiersPython;
	Statistique stat;
	

	//Constructeur de Repertoire:
	
	public Repertoire(String chemin) throws NotDirectoryException {
		super(chemin);
		if(!this.isDirectory()) {
			throw new NotDirectoryException();
		}
		this.stat = new Statistique(this);
		this.fichiers = this.listFiles();
		this.fichiersPython = new ArrayList<FichierPython>();
		
	}
	
	
	//pour lister les fichiers python dans la ArrayList fichiersPython:
	
	public void listerFichierPy() throws NotDirectoryException, NotPythonFileException {
		for(File fichier: fichiers) {
			if(fichier.isDirectory()) {
				Repertoire rep = new Repertoire(fichier.getAbsolutePath());
				rep.listerFichierPy();
				for(FichierPython f:rep.getFichierPy()) {
					this.fichiersPython.add(f);
				}
				
			}
			else {
				if(fichier.getName().toLowerCase().endsWith(".py")) {
				this.fichiersPython.add(new FichierPython( fichier.getAbsolutePath()));
				}
			}
		}
		
		
		
	}
	
	//le nombre de fonction dans ce repertoire:
	public int nombreFonction() throws IOException {
		int nb = 0;
		for(FichierPython f: this.fichiersPython) {
			nb+= f.nombreFonction();
		}
		return nb;
	}
	
	//l'affiche des statistique:
	public void afficheStat() throws IOException {
		System.out.println("Statistique du repertoire : " + this.getName());
		System.out.println("Nombre de fichier analysé : " + this.fichiersPython.size());
		System.out.println("Nombre de fonction dans ce repertoire: " + nombreFonction());
		System.out.println("Pourcentage des fichiers avec le shebang python et encodage UTF-8 : " + stat.pourcentageFichierAvecDeuxLigne() + "%");
		System.out.println("Pourcenrage des fonctions avec les commentaires Pydoc :" + stat.pourcentageFonctionAvecPydoc() + "%");
		System.out.println("Pourcenrage des fonctions avec les annotation de type :" + stat.pourcentageFonctionAvecAnnotation() + "%");
		
	}
	
	//l'affiche des fichiers python :
	public void afficheFile() {
		for(FichierPython fichier : this.fichiersPython) {
			System.out.println(fichier.getAbsolutePath());
			
		}
	}
	
	
	
	public ArrayList<FichierPython> getFichierPy(){
		return this.fichiersPython;
	}
	
	public String getStat() throws IOException {
		return "Statistique du repertoire : " + this.getName() + "\n" + "Nombre de fichier analysé : " + this.fichiersPython.size() + "\n" +"Nombre de fonction dans ce repertoire: " + nombreFonction() + "\n"+ "Pourcentage des fichiers avec le shebang python et encodage UTF-8 : " + stat.pourcentageFichierAvecDeuxLigne() + "%" + "\n" + "Pourcenrage des fonctions avec les commentaires Pydoc :" + stat.pourcentageFonctionAvecPydoc() + "%" + "\n" +"Pourcenrage des fonctions avec les annotation de type :" + stat.pourcentageFonctionAvecAnnotation() + "%" +"\n";  
	}
	
	
	
	
	
}
