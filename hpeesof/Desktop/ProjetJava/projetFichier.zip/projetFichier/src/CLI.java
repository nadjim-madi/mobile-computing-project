import classes.FichierPython;
import classes.Repertoire;

public class CLI {

	public static void main(String[] args) {
		
		if(args.length<1) {
			System.out.println("t'as pas entrer des commandes");
			return;
		}
		 if(args[0].equals("-h")){
			System.out.println("1er argument :");
			System.out.println("[-f] : Fichier ");
			System.out.println("[-d] : Repertoire ");
			System.out.println("[-h] ou [--help] : Aide ");
			
			System.out.println("2eme argument est le repertoire ou le fichier");

			System.out.println("3eme argument :");
			System.out.println("[--type] :  pour vérifier les annotations de type");
			System.out.println("[--head] : pour vérifier les deux premières lignes de commentaire ");
			System.out.println("[--pydoc] :  pour vérifier les commentaires de fonction au format « pydoc »");
			System.out.println("[--sbutf8] : pour l’ajout des 2 premières lignes de commentaire manquantes ");
			System.out.println(" [--comment] : pour l'ajout du squelette pydoc");
			System.out.println("[--stat] : pour les statistiques de repertoire");


			
		}
		 else if(args[0].equals("-d")) {
			 try {
			 Repertoire repertoire = new Repertoire(args[1]);
			 repertoire.listerFichierPy();
			 System.out.println("voici tout les fichiers pythons:");
			 repertoire.afficheFile();
			 if(args.length>1) {
				 if(args[2].equals("--stat")) {
					 repertoire.afficheStat();
				 }
			 }
			 
			 }catch(Exception e) {
				 System.out.println(e.getMessage());
			 }
		 }
		 else if(args[0].equals("-f")) {
			 try {
			 FichierPython fichier = new FichierPython(args[1]);
			 fichier.listerFonctions();
			 int i = 2;
			 while(i< args.length) {
				 if(args[i].equals("--type")) {
					 if(fichier.contientTypage()) {
						 System.out.println("Le fichier contient les annotation de type");
					 }
					 else {
						 System.out.println("Le fichier ne contient pas les annotations de type");
					 }
				 }
				 else if(args[i].equals("--head")) {
					 if(fichier.contientLesDeuxLignes()) {
						 System.out.println("Le fichier contient les 2 premieres lignes");
					 }
					 else {
						 System.out.println("Le fichier ne contient pas les 2 premieres lignes");
					 }
				 }
				 else if(args[i].equals("--pydoc")) {
					 if(fichier.contientPydoc()) {
						 System.out.println("Le fichier contient les PyDoc");
					 }
					 else {
						 System.out.println("Le fichier ne contient pas les PyDoc");
					 }
					 
					 
					 
				 }
				 else if(args[i].equals("--sbutf8")) {
					 fichier.ajoutDeuxLigne();
				 }
				 else if(args[i].equals("--comment")) {
					 fichier.ajoutPyDoc();
				 }
			 
				 
				i = i+1; 
			 
			 
			 }
			 }catch(Exception e) {
				 System.out.println(e.getMessage());
			 }
		 }
		 
		 
		
		
		 
		 
		 return;
		
		
	}

}