package exception;

public class NotDirectoryException extends Exception {
	
	public NotDirectoryException() {
		super("le chemin que vous avez donné n'est pas un repertoire");
	}
	
}