package exception;

public class PremiereLignesExisteException extends Exception {

	
	public PremiereLignesExisteException() {
		super("Les deux premieres lignes existent deja vous ne pouvez pas rajouter");
	}
}
