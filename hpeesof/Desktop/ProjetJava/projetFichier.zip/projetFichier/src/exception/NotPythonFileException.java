package exception;

public class NotPythonFileException extends Exception{
	
		public NotPythonFileException() {
			super("le chemin que vous avez donné n'est pas un fichier Python");
		}
}
