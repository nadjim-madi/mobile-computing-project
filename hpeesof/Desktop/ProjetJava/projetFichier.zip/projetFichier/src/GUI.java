import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import classes.*;
import exception.NotDirectoryException;
import exception.NotPythonFileException;
import exception.PremiereLignesExisteException;

public class GUI extends JFrame implements ActionListener{
	private ArrayList<JButton> listeBoutton = new ArrayList<JButton>();
	private JButton aide = new JButton("Aide");
	private JButton tousLesFichier = new JButton("Les Fichier Python");
	private File fichier;
	private JButton rapport = new JButton("Rapport");
	private JButton statButton = new JButton("Statistique");
	private JPanel bas = new JPanel();
	private JButton ajouterFichier;
	private JButton supprimerFichier= new JButton("Supprimer Le Fichier");
	private JPanel haut = new JPanel();
	private JButton fichierButton = new JButton();
	private JPanel contCentre =  new JPanel();
	private JPanel contGauche = new JPanel();
	private JPanel contDroit = new JPanel();
	private JButton typageButton = new JButton("Verifier erreur de typage");
	private JButton sheyBangButton = new JButton("Verifier l'existance des 2 premieres lignes");
	private JButton pydocButton = new JButton("Verifier l'existance du pydoc");
	private JButton ajouterLigne = new JButton("Ajouter 2 lignes");
	private JButton ajouterPydoc = new JButton("Ajouter le Pydoc");
	private JPanel panel2 = new JPanel();
	private JPanel panel = new JPanel();


	
	public GUI() {
		
		
		
		this.setTitle( "Gestion Fichier Python");
		this.setSize(600,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		ImageIcon image = new ImageIcon("src/image/Python.svg.png");
		this.setIconImage(image.getImage());
		this.getContentPane().setBackground(new Color(120,200,250));
		
		

		contCentre.setLayout(new BorderLayout());
		
		bas.setVisible(true);
		
		ajouterFichier = new JButton("Selectionner Le Nouveau Fichier");
        ajouterFichier.setFocusPainted(false);

        contCentre.setVisible(false);                
        fichierButton.setAlignmentX(Component.LEFT_ALIGNMENT); 
        contGauche.setBackground(new Color(120,200,250));
        contGauche.setBorder(BorderFactory.createEmptyBorder(0,40,0,0));
        contGauche.add(fichierButton);
        
        haut.setLayout(new GridLayout(0,2));
        haut.add(ajouterFichier);
        haut.add(supprimerFichier);
        
        contDroit.setBackground(new Color(120,200,250));
        contDroit.setBorder(BorderFactory.createEmptyBorder(0,0,0,40));
        contDroit.setVisible(false);
        
        contCentre.setBackground(new Color(120,200,250));
        contCentre.add(contGauche,BorderLayout.WEST);
        contCentre.add(contDroit,BorderLayout.EAST);
        
        
        bas.setLayout(new BorderLayout());
        bas.setBorder(BorderFactory.createEmptyBorder(20, 30, 5, 20));
        bas.add(aide, BorderLayout.WEST);
        bas.add(rapport,BorderLayout.EAST);
        bas.setBackground(new Color(120,200,250));
        

        Iterator<JButton> iter = listeBoutton.iterator();
		while(iter.hasNext()) {
			JButton button = iter.next();
			button.addActionListener(this);
			
		}
        
        
        ajouterFichier.addActionListener(this);
        fichierButton.addActionListener(this);
        supprimerFichier.addActionListener(this);
        tousLesFichier.addActionListener(this);
        statButton.addActionListener(this);
        sheyBangButton.addActionListener(this);
        ajouterLigne.addActionListener(this);
        pydocButton.addActionListener(this);
        typageButton.addActionListener(this);
        rapport.addActionListener(this);
        
        this.setLayout(new BorderLayout());
        
        
		this.add(haut, BorderLayout.NORTH);
		this.add(contCentre, BorderLayout.CENTER);
		this.add(bas, BorderLayout.SOUTH);
		

        
        
        
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
			if(e.getSource() == ajouterFichier) {
				panel2.removeAll();
				panel2.revalidate();
				panel2.repaint();
				panel2.setVisible(false);
				
				panel.removeAll();
				panel.revalidate();
				panel.repaint();
				
				contDroit.removeAll();
				contDroit.revalidate();
				contDroit.repaint();
				
				contGauche.removeAll();
				contGauche.revalidate();
				contGauche.repaint();
				JFileChooser fileChooser = new JFileChooser();
		        fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		        
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    fichier = selectedFile;
                    JOptionPane.showMessageDialog(null, "Fichier sélectionné : " + selectedFile.getName());
                    fichierButton.setText(selectedFile.getName());
                    contGauche.removeAll();
                    contGauche.add(fichierButton);
                    contCentre.setVisible(true);
                    ajouterFichier.setText("Changer Le Fichier");
                    contDroit.setVisible(false);
                }
                
                
			}
			if(e.getSource() == fichierButton) {
				if(fichier.isFile()) {
			        Box boxVerticale = Box.createVerticalBox();

			        
			        boxVerticale.add(sheyBangButton);
			        boxVerticale.add(typageButton);
			        boxVerticale.add(pydocButton);
			        
			        contDroit.add(boxVerticale);
				contDroit.setVisible(true);
				}
				else {
					 Box boxVerticale = Box.createVerticalBox();
					 boxVerticale.add(tousLesFichier);
					 boxVerticale.add(statButton);
					 contDroit.add(boxVerticale);
					contDroit.setVisible(true);
					

					 
					 
					
					
				}
			}
			
			if(e.getSource() == supprimerFichier) {
				if(contCentre.isVisible()) {
		        int choix = JOptionPane.showConfirmDialog(null, "Etes vous sur de vouloir supprimer le fichier", "Confirmation", JOptionPane.YES_NO_OPTION);
		        if(choix == JOptionPane.YES_OPTION) {

				ajouterFichier.setText("Selectionner Le Nouveau Fichier");
				panel2.removeAll();
				panel2.revalidate();
				panel2.repaint();
				panel2.setVisible(false);
				
				panel.removeAll();
				panel.revalidate();
				panel.repaint();
				
				contDroit.removeAll();
				contDroit.revalidate();
				contDroit.repaint();
				
				contGauche.removeAll();
				contGauche.revalidate();
				contGauche.repaint();
				
				contCentre.setVisible(false);
		        }
				}
				
			}
			

			if(e.getSource() == tousLesFichier) {
				contDroit.removeAll();
				contDroit.revalidate();
				contDroit.repaint();
				contGauche.removeAll();
				contGauche.revalidate();
				contGauche.repaint();
				
				try {
					 Box boxVerticale = Box.createVerticalBox();


					Repertoire rep = new Repertoire(fichier.getAbsolutePath());
					rep.listerFichierPy();
					Iterator<FichierPython> iter = rep.getFichierPy().iterator();
					while(iter.hasNext()) {
						FichierPython fi = iter.next();
						JButton button = new JButton(fi.getName());
						boxVerticale.add(button);
						listeBoutton.add(button);
					}
					contGauche.add(boxVerticale);
					
					
				} catch (NotDirectoryException e1) {
			        JOptionPane.showMessageDialog(null, "C'est pas un repertoire", "Not Directory", JOptionPane.WARNING_MESSAGE);
				} catch (NotPythonFileException e1) {
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);

				}
			}
			
			Iterator<JButton> iter = listeBoutton.iterator();
			while(iter.hasNext()) {
				JButton button = iter.next();
				if(e.getSource() == button) {

					 Box boxVerticale = Box.createVerticalBox();
					 boxVerticale.add(tousLesFichier);
					 boxVerticale.add(statButton);
					 contDroit.add(boxVerticale);
					contDroit.setVisible(true);
					
				}
			}
			
			if(e.getSource() == statButton) {
				try {
					panel2.removeAll();
					panel2.revalidate();
					panel2.repaint();
					panel2.setVisible(false);
					
					panel.removeAll();
					panel.revalidate();
					panel.repaint();
					
					Repertoire rep = new Repertoire(fichier.getAbsolutePath());
					rep.listerFichierPy();
					String s = rep.getStat();
					JLabel stat = new JLabel("<html>" + s.replaceAll("\n", "<br>") + "</html>");
					panel2.setBackground(Color.black);
					stat.setForeground(Color.white);
					stat.setFont(new Font("Times New Roman", Font.BOLD , 16));
					panel2.add(stat);
					panel2.setBorder(new LineBorder(Color.white,2,true));

					panel.setBackground(new Color(120,200,250));
			        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
					panel.add(panel2);
					panel2.setVisible(true);
					
					contCentre.add(panel,BorderLayout.SOUTH);
					contCentre.revalidate();
					contCentre.repaint();
					
					
					
				
					
				} catch (NotDirectoryException e1) {
					// TODO Auto-generated catch block
			        JOptionPane.showMessageDialog(null, "C'est pas un repertoire", "Not Directory", JOptionPane.WARNING_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NotPythonFileException e1) {
					// TODO Auto-generated catch block
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);
				}
			}
			
			if(e.getSource() == sheyBangButton) {
				try {
					panel2.removeAll();
					panel2.revalidate();
					panel2.repaint();
					panel2.setVisible(false);
					
					panel.removeAll();
					panel.revalidate();
					panel.repaint();
					
					FichierPython fp = new FichierPython(fichier.getAbsolutePath());
					JLabel text ;
					
					
					panel2.setBackground(Color.black);
					if(fp.contientLesDeuxLignes()) {
						ImageIcon correcte = new ImageIcon("src/image/rsz_1check-157822_1280.png");
						
						text = new JLabel("Le Fichier contient les 2 premieres lignes ", correcte,JLabel.CENTER);
						text.setForeground(Color.white);
						text.setFont(new Font("Times New Roman", Font.BOLD , 16));
						panel2.add(text);
						panel2.setBorder(new LineBorder(Color.white,2,true));

						panel.setBackground(new Color(120,200,250));
				        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
						panel.add(panel2);
						panel2.setVisible(true);
					}
					else {
						ImageIcon correcte = new ImageIcon("src/image/rsz_incorrect-icon-in-sticker-style-on-transparent-background-png.png");
						text = new JLabel("Le Fichier ne contient pas les 2 premieres lignes ", correcte,JLabel.CENTER);
						text.setForeground(Color.white);
						text.setFont(new Font("Times New Roman", Font.BOLD , 16));
						
						panel.setLayout(new GridLayout(2,0));
						panel2.add(text);
						panel2.setBorder(new LineBorder(Color.white,2,true));
						
						JPanel panel3 = new JPanel();
						panel3.setBackground(new Color(120,200,250));

						panel3.add(ajouterLigne);
						panel3.setBorder(BorderFactory.createEmptyBorder(0,50,0,50));
						
						panel.setBackground(new Color(120,200,250));
				        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
						panel.add(panel2);
						panel2.setVisible(true);
						panel.add(panel3);
						
						
						
					}


					
					contCentre.add(panel,BorderLayout.SOUTH);
					contCentre.revalidate();
					contCentre.repaint();
					
					
					
					
					
					
				} catch (NotPythonFileException e1) {
					// TODO Auto-generated catch block
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
			if(e.getSource() == ajouterLigne) {
				try {
					FichierPython fip = new FichierPython(fichier.getAbsolutePath());
					fip.ajoutDeuxLigne();
					JOptionPane.showMessageDialog(null, "2 premiere Ligne ajoutée ");
					
					panel2.removeAll();
					panel2.revalidate();
					panel2.repaint();
					panel2.setVisible(false);
					
					panel.removeAll();
					panel.revalidate();
					panel.repaint();
					
				} catch (NotPythonFileException e1) {
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (PremiereLignesExisteException e1) {
			        JOptionPane.showMessageDialog(null, "2 premieres lignes existe deja", "Existance of shebang", JOptionPane.WARNING_MESSAGE);
				}
				
				
				
			}
			if(e.getSource() == pydocButton) {
				try {
					panel2.removeAll();
					panel2.revalidate();
					panel2.repaint();
					panel2.setVisible(false);
					
					panel.removeAll();
					panel.revalidate();
					panel.repaint();
					FichierPython fp = new FichierPython(fichier.getAbsolutePath());
					JLabel text ;
					
					fp.listerFonctions();
					panel2.setBackground(Color.black);
					if(fp.contientPydoc()) {
						ImageIcon correcte = new ImageIcon("src/image/rsz_1check-157822_1280.png");
						
						text = new JLabel("Le Fichier contient le squelette pydoc ", correcte,JLabel.CENTER);
						text.setForeground(Color.white);
						text.setFont(new Font("Times New Roman", Font.BOLD , 16));
						panel2.add(text);
						panel2.setBorder(new LineBorder(Color.white,2,true));

						panel.setBackground(new Color(120,200,250));
				        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
						panel.add(panel2);
				        panel2.setVisible(true);

					}
					else {
						ImageIcon correcte = new ImageIcon("src/image/rsz_incorrect-icon-in-sticker-style-on-transparent-background-png.png");
						text = new JLabel("Le Fichier ne contient pas le squelette pydoc", correcte,JLabel.CENTER);
						text.setForeground(Color.white);
						text.setFont(new Font("Times New Roman", Font.BOLD , 16));
						
						panel.setLayout(new GridLayout(2,0));
						panel2.add(text);
						panel2.setBorder(new LineBorder(Color.white,2,true));
						
						JPanel panel3 = new JPanel();
						panel3.setBackground(new Color(120,200,250));

						panel3.add(ajouterPydoc);
						panel3.setBorder(BorderFactory.createEmptyBorder(0,50,0,50));
						
						panel.setBackground(new Color(120,200,250));
				        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
						panel.add(panel2);
				        panel2.setVisible(true);

						panel.add(panel3);
						
						
						
					}


					
					contCentre.add(panel,BorderLayout.SOUTH);
					contCentre.revalidate();
					contCentre.repaint();
					
					
					
					
					
					
				} catch (NotPythonFileException e1) {
					// TODO Auto-generated catch block
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
			if(e.getSource() == ajouterPydoc) {
				try {
					FichierPython fip = new FichierPython(fichier.getAbsolutePath());
					fip.listerFonctions();
					fip.ajoutPyDoc();
					JOptionPane.showMessageDialog(null, "Pydoc ajoutée ");
					
					panel2.removeAll();
					panel2.revalidate();
					panel2.repaint();
					panel2.setVisible(false);
					
					panel.removeAll();
					panel.revalidate();
					panel.repaint();
					
				} catch (NotPythonFileException e1) {
					// TODO Auto-generated catch block
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
			
			if(e.getSource() == typageButton) {
				try {
					panel2.removeAll();
					panel2.revalidate();
					panel2.repaint();
					panel2.setVisible(false);
					
					panel.removeAll();
					panel.revalidate();
					panel.repaint();
					FichierPython fp = new FichierPython(fichier.getAbsolutePath());
					JLabel text ;
					
					
					fp.listerFonctions();
					panel2.setBackground(Color.black);
					if(fp.contientTypage()) {
						ImageIcon correcte = new ImageIcon("src/image/rsz_1check-157822_1280.png");
						
						text = new JLabel("Le Fichier contient les annotation de type ", correcte,JLabel.CENTER);
						text.setForeground(Color.white);
						text.setFont(new Font("Times New Roman", Font.BOLD , 16));
						panel2.add(text);
						panel2.setBorder(new LineBorder(Color.white,2,true));

						panel.setBackground(new Color(120,200,250));
				        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
						panel.add(panel2);
				        panel2.setVisible(true);

					}
					else {
						ImageIcon correcte = new ImageIcon("src/image/rsz_incorrect-icon-in-sticker-style-on-transparent-background-png.png");
						text = new JLabel("Le Fichier ne contient pas les annotations de type", correcte,JLabel.CENTER);
						text.setForeground(Color.white);
						text.setFont(new Font("Times New Roman", Font.BOLD , 16));
						
						panel.setLayout(new GridLayout(2,0));
						panel2.add(text);
						panel2.setBorder(new LineBorder(Color.white,2,true));
						

						
						panel.setBackground(new Color(120,200,250));
				        panel.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
						panel.add(panel2);
				        panel2.setVisible(true);

						
						
					}
					contCentre.add(panel,BorderLayout.SOUTH);
					contCentre.revalidate();
					contCentre.repaint();
					
				}catch (NotPythonFileException e1) {
						// TODO Auto-generated catch block
			        JOptionPane.showMessageDialog(null, "C'est pas un fichier python", "Not Python File", JOptionPane.WARNING_MESSAGE);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}	
						
			}
			
			if(e.getSource() == rapport) {
				String cheminFichier = "src/rapport/Rapport_de_Projet.pdf";

                try {
                    File fichier = new File(cheminFichier);
                    if (!Desktop.isDesktopSupported()) {
                        JOptionPane.showMessageDialog(null, "Desktop n'est pas supporté");
                        return;
                    }
                    Desktop desktop = Desktop.getDesktop();
                    if (fichier.exists()) {
                        desktop.open(fichier);
                    } else {
                        JOptionPane.showMessageDialog(null, "Fichier non trouvé : " + cheminFichier);
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Erreur lors du téléchargement du fichier : " + ex.getMessage());
                }
            }
			}
			
			
			
				
			}
	

	
			



	

